package com.feathersoft.trainingproject.OnlineTrainTicketBooking.dto;

public enum CompartmentType {
    SLEEPER,
    AC_SLEEPER,
    FIRST_CLASS,
    GENERAL
}
